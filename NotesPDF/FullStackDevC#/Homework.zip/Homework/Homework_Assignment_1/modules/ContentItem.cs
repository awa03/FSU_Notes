class ContentItem{
    // Content Name String
    public string? ContentName{
        get;
        set;
    }
    public string? ContentDesc{
        get;
        set;
    }
    public string? Path{
        get;
        set;
    }
    
}